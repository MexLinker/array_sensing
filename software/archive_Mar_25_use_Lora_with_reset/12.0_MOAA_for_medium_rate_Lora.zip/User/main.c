/*
 *@Note
 *GPIO routine:
 *PA0 push-pull output.
 *
 */

#include "debug.h"

#include "soft_spi_byMax.h"

#include "op_adc_byMax.h"



void GPIO_Input_Init_for_lora(void)
{
    GPIO_InitTypeDef GPIO_InitStructure = {0};

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;          // ʹ��PA1
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;      // �������루Ĭ�ϵ͵�ƽ��
    GPIO_Init(GPIOA, &GPIO_InitStructure);
}

void GPIO_Output_Init_for_lora(void)
{
    GPIO_InitTypeDef GPIO_InitStructure = {0};

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;   // �������ģʽ
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;    // ����ٶȿɸ�����Ҫ����
    GPIO_Init(GPIOA, &GPIO_InitStructure);
}

void LoRa_GPIO_Toggle(void)
{

        GPIO_SetBits(GPIOA, GPIO_Pin_10);

        GPIO_ResetBits(GPIOA, GPIO_Pin_10);
        Delay_Ms(100);

        GPIO_SetBits(GPIOA, GPIO_Pin_10);

}

//void LoRa_GPIO_Toggle(void)
//{
//
//        GPIO_ResetBits(GPIOA, GPIO_Pin_10);
//
//        GPIO_SetBits(GPIOA, GPIO_Pin_10);
//        Delay_Ms(100);
//
//        GPIO_ResetBits(GPIOA, GPIO_Pin_10);
//
//}






void Wait_For_Trigger(void)
{
    // ��¼��ʼ��ƽ״̬
    uint8_t initial_state = GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_10);

    while(1)
    {
        uint8_t current_state = GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_10);

        // һ����ƽ���ʼ״̬��ͬ�����˳�����
        if(current_state != initial_state)
        {
            return;
        }

        Delay_Ms(10); // ��ʱ������CPUռ��
    }
}





/*********************************************************************
 * @fn      main
 *
 * @brief   Main program.
 *
 * @return  none
 */
int main(void)
{

    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_1);
    SystemCoreClockUpdate();
    Delay_Init();
    USART_Printf_Init(115200);
    printf("SystemClk:%d\r\n", SystemCoreClock);
    printf( "ChipID:%08x\r\n", DBGMCU_GetCHIPID() );
    printf("GPIO Toggle TEST\r\n");



        Soft_SPI_Init(); // ��ʼ����SPI����

            u16 ADC_val;

            uint16_t x_to_turn = 1;

            MX_Init();

            OPA1_Init();

            MOAA_GPIO_Init();

            uint8_t x_n = 0;

            ADC_Channel3_Init();


            // GPIO_Input_Init_for_lora();

            char buffer[1024];  // �����������ڴ洢����
            char temp[10];      // ��ʱ�ַ���������ת�� ADC_val

            GPIO_Output_Init_for_lora();


            while (1) {
                    for (uint8_t x_n = 0; x_n <= 0x0F; x_n = x_n + 1) {

                        //Delay_Ms(1000);





                        turn_off_Nth_sw(0xFFFF & (0x0001 << x_n));
                        Delay_Ms(5);
                        MOAA_GPIO_turn_n_on(x_to_turn << x_n);
                        Delay_Ms(5);

                        // Wait_For_Trigger(); // ����ֱ����⵽�½���

                        // ��ջ�����
                        buffer[0] = '\0';

                        for (uint8_t y_n = 0; y_n <= 0x0F; y_n += 1) {
                            MX_turn_n_on(y_n);
                            Delay_Ms(1);
                            uint16_t ADC_val = Get_ADC_Average(ADC_Channel_2, 1);

                            // �� ADC_val ת��Ϊȥ��ǰ������ַ���
                            sprintf(temp, "%d", ADC_val);
                            char* ptr = temp;
                            while (*ptr == '0' && *(ptr + 1) != '\0') {
                                ptr++;
                            }
                            // ׷�ӵ�������
                            strcat(buffer, ptr);
                            if (y_n < 0x0F) {
                                strcat(buffer, ",");
                            }
                        }

                        // ��ӡ x_n �Ͷ�Ӧ�� y_n ����
                        printf("x_n=%d:%s\r\n", x_n, buffer);



                        /*

                        Delay_Ms(100);

                        LoRa_GPIO_Toggle();

                        Delay_Ms(100);

                        */

                        /* send rate stable, PhD.Zhang satisfied

                        Delay_Ms(10);

                        LoRa_GPIO_Toggle();

                        Delay_Ms(250);

                        */

                        Delay_Ms(10);

                        LoRa_GPIO_Toggle();

                        Delay_Ms(250);








                        // Wait_For_Trigger(); // ����ֱ����⵽�½���





                    }



                }
}
